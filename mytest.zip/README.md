# Simple Chat Server Example
clone repository.
Start server with >> **py -3 -m server**
Connect to server with >> **py -3 -m client_user**
