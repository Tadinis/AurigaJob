import unittest
from time import sleep
import subprocess

class TestStringMethods(unittest.TestCase):
    def test1(self):
        server = subprocess.Popen(
            ["python", "server.py"],
            stdin=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            bufsize=1,
            universal_newlines=True
        )
        client = subprocess.Popen(
            ["python", "client_user.py"],
            stdin=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            bufsize=1,
            universal_newlines=True
        )
        sleep(5)
        try:
            client.stdin.write("tadas\n")
            sleep(5)
        finally:
            try:
                client.stdin.write("!quit\n")
                sleep(5)
                client.terminate()
                client.wait()
                server.terminate()
                server.wait()
            except Exception as er:
                print(f'Yolo close failed: {str(er)}')


if __name__ == '__main__':
    unittest.main()



