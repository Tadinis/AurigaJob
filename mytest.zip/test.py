import unittest
from time import sleep
import subprocess
import datetime
import sys
from utils import Config
from logger import Logger

class TestStringMethods(unittest.TestCase):
    def setUp(self):
        global server
        server = subprocess.Popen(
            ["python", "server.py"],
            stdin=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            bufsize=1,
            universal_newlines=True
        )
        global client
        client = subprocess.Popen(
            ["python", "client_user.py"],
            stdin=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            bufsize=1,
            universal_newlines=True
        )
        sleep(1)
        
    def tearDown(self):
        try:
            client.terminate()
            client.wait()
            server.terminate()
            server.wait()
        except Exception as er:
            Logger.error(str(er))
            print(f'Close failed: {str(er)}')


    def test1(self):
        try:
            client.stdin.write("test\n")
            sleep(1)
        finally:
            client.stdin.write("!quit\n")
            sleep(1)
                         
        f = open(f"{datetime.date.today()}_server_logger.txt", "r")
        check = False
        for line in f.readlines():
            if 'test' in line:
                check = True
        f.close()
        try:
            self.assertTrue(check)
            Logger.info("Test 1 Success")
        except Exception as er:
            Logger.error(str(er))


    def test2(self):
        #generate message
        msg = ''
        while sys.getsizeof(msg.encode('utf-8')) < Config.BUFFER_SIZE + 1000:
            msg = msg + "a"
        msg = msg + "OVERFLOW"
        try:
            #Sending message over the buffer size
            client.stdin.write(msg)
            sleep(1)
            client.stdin.write("!quit\n")
            sleep(1)
        except Exception as er:
                print(f'[Exception] {str(er)}')  

        f = open(f"{datetime.date.today()}_server_logger.txt", "r")
        check = False
        for line in f.readlines():
            if 'OVERFLOW' in line:
                check = True
        f.close()
        
        try:
            self.assertTrue(check)
            Logger.info("Test 2 Success")
        except Exception as er:
            Logger.error(str(er))

class TestTryExcept(unittest.TestCase):
    def setUp(self):
        global server
        server = subprocess.Popen(
            ["python", "server.py"],
            stdin=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            bufsize=1,
            universal_newlines=True
        )
        global client
        client = subprocess.Popen(
            ["python", "client_user.py"],
            stdin=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            bufsize=1,
            universal_newlines=True
        )
        sleep(1)

    def tearDown(self):
        try:
            client.terminate()
            client.wait()
            server.terminate()
            server.wait()
        except Exception as er:
            Logger.error(str(er))
            print(f'Close failed: {str(er)}')   


    def test_excpetion1(self):
        try:
            client.stdin.write(["hey", "bye"])
        except TypeError as e:
            Logger.error(str(e))
            self.assertEqual(type(e),TypeError)
        else:
            Logger.debug("TypeError not raised")
            self.fail("TypeError not raised")


    def test_excpetion2(self):
        try:
            client.stdin.write((1, 2))
        except TypeError as e:
            Logger.error(str(e))
            self.assertEqual(type(e),TypeError)
        else:
            Logger.debug("TypeError not raised")
            self.fail("TypeError not raised")


if __name__ == '__main__':
    Logger(filename="test_logger")
    unittest.main()



